# 🧪 GUÍA RÁPIDA DE TESTING

**Tiempo de testing:** ~20 minutos  
**Nivel:** Principiante - Intermedio  

---

## ✅ PASO 1: Preparar el Ambiente

### 1.1 Copiar archivos a raíz
```bash
# En PowerShell (en d:\Proyectos\Tienda12)
Copy-Item "index-moderno.html" -Destination "index.html" -Force
Copy-Item "styles-moderno.css" -Destination "styles.css" -Force
Copy-Item "app-moderno.js" -Destination "app.js" -Force
```

### 1.2 Abrir en navegador
```
Opción A: Click derecho en index.html → "Abrir con Chrome"
Opción B: Arrastrar index.html a Chrome
Opción C: Ctrl+L en Chrome, pegar: file:///d:/Proyectos/Tienda12/index.html
```

### 1.3 Abrir DevTools
- **Windows/Linux:** F12 o Ctrl+Shift+I
- **Mac:** Cmd+Option+I

---

## ✅ PASO 2: Testing Desktop (1920x1080)

### 2.1 Productos y Grid
```
VERIFICAR:
[ ] Productos cargados (no en blanco)
[ ] Grid: 5 columnas
[ ] Cada card tiene imagen, nombre, precio
[ ] Hover: card sube 8px
[ ] Hover: sombra se expande
[ ] Animación: fade-in en cascada (no todo de una vez)
```

### 2.2 Carrito Sidebar
```
VERIFICAR:
[ ] Carrito visible a la derecha (280px)
[ ] Título "🛒 Tu Carrito"
[ ] Botón "✕" para cerrar (opcional en desktop)
[ ] Items vacío: muestra icono 🛍️
[ ] Inputs: Nombre y Ciudad visibles
[ ] Botón: "✓ Finalizar Pedido"
```

### 2.3 Agregar al Carrito
```
TEST:
1. Click en card "Agregar"
2. VERIFICAR: Toast aparece (arriba derecha)
   └─ Mensaje: "✓ [Producto] añadido"
   └─ Color: verde
   └─ Auto-desaparece en 3 segundos
3. VERIFICAR: Badge carrito actualiza (número)
4. VERIFICAR: Producto aparece en carrito
5. VERIFICAR: Total actualiza

REPETIR: 3 productos diferentes
```

### 2.4 Modificar Cantidad
```
TEST:
1. En card: [-] [1] [+]
2. Click [+] → Cambiar a 2
3. Click [+] → Cambiar a 3
4. Click [-] → Cambiar a 2
5. Click Agregar

EN CARRITO:
1. Item aparece con cantidad 2
2. Botones [-] [x] [+] visibles
3. Click [-] → cantidad baja a 1
4. Click [-] → item se elimina
5. Toast aparece: "Producto removido"
```

### 2.5 Paginación
```
TEST:
1. Ver página 1/5
2. Click [Siguiente ▶]
3. VERIFICAR: Cambiar a página 2
4. VERIFICAR: Productos diferentes
5. Click [◀ Anterior]
6. VERIFICAR: Volver a página 1
7. Button [Anterior] debe estar disabled en página 1
8. Button [Siguiente] debe estar disabled en última página
```

### 2.6 Filtro de Categorías
```
TEST:
1. Selector: "Todas las categorías"
2. Click → Seleccionar categoría
3. VERIFICAR: Grid actualiza
4. VERIFICAR: Vuelve a página 1
5. VERIFICAR: Otros productos
6. Click → Seleccionar otra categoría
7. VERIFICAR: Cambio de productos

VALIDA: Las categorías se cargan automáticamente
```

### 2.7 Finalizar Pedido
```
TEST:
1. Carrito con items
2. Inputs vacíos
3. Click Finalizar
4. VERIFICAR: Toast error
   └─ Mensaje: "Nombre debe tener mínimo 3 caracteres"
   └─ Color: rojo

4. Input Nombre: "AB" (2 caracteres)
5. Input Ciudad: "Cali"
6. Click Finalizar
7. VERIFICAR: Error "Nombre debe tener mínimo 3 caracteres"

8. Input Nombre: "Juan Carlos López"
9. Input Ciudad: "Cali"
10. Click Finalizar
11. VERIFICAR: Botón cambia a "Enviando..." (desactivado)
12. ESPERAR: 2-3 segundos
13. VERIFICAR: Toast éxito
    └─ Mensaje: "✓ Pedido #XXXXX creado correctamente"
14. VERIFICAR: Carrito se cierra (collapsa)
15. VERIFICAR: Campos limpios
16. VERIFICAR: Badge carrito = 0
```

---

## ✅ PASO 3: Testing Tablet (768px)

### 3.1 Cambiar Viewport
En DevTools:
```
1. Ctrl+Shift+M (Toggle device toolbar)
2. Seleccionar: iPad (768x1024)
3. O ingresar width: 768
```

### 3.2 Layout
```
VERIFICAR:
[ ] Grid: 3 columnas (no 5)
[ ] Carrito NO es sidebar
[ ] Carrito es bottom sheet (abajo)
[ ] Carrito ocupa 100% ancho
[ ] Carrito altura: ~60% pantalla
[ ] Botón toggle: VISIBLE
```

### 3.3 Interactividad
```
TEST:
1. Botón toggle 🛒 (arriba)
2. Click → Carrito se desliza hacia arriba
3. Muestra: Items, Total, Inputs, Botón
4. VERIFICAR: Scroll en items
5. Click X → Carrito se desliza hacia abajo
6. Click toggle nuevamente

VALIDA: Animación suave 0.3s
```

### 3.4 Toasts en Tablet
```
TEST:
1. Agregar producto
2. Toast aparece (NO debe ocultar carrito)
3. VERIFICAR: Posición: arriba derecha
4. VERIFICAR: Se lee todo
```

---

## ✅ PASO 4: Testing Móvil (375px)

### 4.1 Cambiar Viewport
En DevTools:
```
1. Ctrl+Shift+M
2. Seleccionar: iPhone 12 (390x844)
3. O ingresar width: 375
```

### 4.2 Layout
```
VERIFICAR:
[ ] Grid: 2 columnas
[ ] Header: Título pequeño
[ ] Selector categorías: 100% ancho
[ ] Botón FAB 🛒 (flotante, abajo-derecha)
[ ] Badge contador visible en FAB
[ ] Carrito NO visible inicialmente
```

### 4.3 FAB (Floating Action Button)
```
TEST:
1. Scroll down
2. FAB permanece visible
3. Badge muestra contador
4. Click FAB → Bottom sheet sube
5. VERIFICAR: Ocupar 60-70% pantalla
6. VERIFICAR: Scroll en items
7. VERIFICAR: Inputs accesibles
8. Click X → Bottom sheet baja

NOTA: FAB debe ser 56x56px mínimo (accesibilidad)
```

### 4.4 Agregar en Móvil
```
TEST:
1. Card: [-] [1] [+] [Agregar]
2. Cambiar cantidad a 3
3. Click Agregar
4. Toast aparece (sin ocultar navegación)
5. Badge FAB actualiza
6. FAB semi-transparente para ver contenido detrás

VALIDA: Botones son big enough (hit target 48px+)
```

### 4.5 Validación en Móvil
```
TEST:
1. Click FAB → Abre carrito
2. Click "Finalizar Pedido"
3. Toast error grande y legible
4. Input name: escribe "Juan"
5. Input city: escribe "Cali"
6. Click Finalizar
7. VERIFICAR: Validación ok
8. VERIFICAR: Toast éxito visible

NOTA: Teclado no debe ocultar inputs
```

---

## ✅ PASO 5: Testing Responsive En Tiempo Real

### 5.1 Chrome DevTools Responsive
```
1. F12 → DevTools
2. Ctrl+Shift+M → Device toolbar
3. Dropdown arriba → Seleccionar dispositivos:
   - iPhone 12
   - Samsung Galaxy S20
   - iPad
   - Pixel 4
   
4. O ingresar custom:
   - 1920 (desktop)
   - 768 (tablet)
   - 375 (móvil)
   - 360 landscape
```

### 5.2 Orientation Change
```
TEST (en móvil):
1. Portrait (375x812)
   - Verificar layout
2. Landscape (812x375)
   - Click botón rotate (DevTools)
   - VERIFICAR: Grid redimensiona
   - VERIFICAR: FAB accesible
   - VERIFICAR: Carrito funciona
```

---

## ✅ PASO 6: Testing Dark Mode

### 6.1 Activar Dark Mode del SO
**Windows:**
```
Settings → Personalization → Colors → Dark
```

**Mac:**
```
System Preferences → General → Dark
```

### 6.2 Verificar En Navegador
```
TEST:
1. Recargar página (F5)
2. VERIFICAR: Colores inverted
   - Fondo: #121212 (oscuro)
   - Texto: #ffffff (blanco)
3. VERIFICAR: Legibilidad ok
4. VERIFICAR: Contraste suficiente

NOTA: Si navegador usa light, fuerza en DevTools:
- DevTools → 3 puntos → Preferences
- Appearance → Dark
```

---

## ✅ PASO 7: Testing Keyboard Navigation

### 7.1 Sin Mouse
```
TEST:
1. Tab → Enfoca Select Categorías
2. Tab → Enfoca Card 1 Button
3. Tab → Enfoca Card 2 Button
4. Shift+Tab → Retrocede
5. Enter → Presiona botón enfocado

VERIFICAR:
[ ] Outline visible alrededor de elemento enfocado
[ ] Outline es 2px, color primario
[ ] Sin outline perdido
```

### 7.2 Navegación Carrito
```
TEST:
1. Tab repetido hasta llegar a FAB
2. Enter → Abre carrito
3. Tab → Enfoca input nombre
4. Escribe: "Juan Carlos"
5. Tab → Enfoca input ciudad
6. Escribe: "Cali"
7. Tab → Enfoca botón Finalizar
8. Enter → Envía pedido

VALIDA: Sin mouse, todo funciona
```

---

## ✅ PASO 8: Testing Performance

### 8.1 Verificar Console
En DevTools (F12):
```
1. Console tab
2. NO debe haber errores rojos
3. Warnings amarillos = ok (avisos)
4. Errors rojos = ❌ problema

COPIAR Y PEGAR EN CONSOLE:
verCarrito()          ← Ver carrito actual
limpiarCarrito()      ← Limpiar carrito
verCache()            ← Ver cache de productos
```

### 8.2 Network Performance
```
TEST:
1. DevTools → Network tab
2. F5 (reload)
3. VERIFICAR:
   - Loaded: ~50-100 items
   - Size: <500KB
   - Time: <2 segundos
   - Imágenes: Status 200 (ok)
   
4. Click en cada request:
   - App.js: ~12KB
   - Styles.css: ~40KB
   - Google API: 200 (exitoso)
```

### 8.3 Lighthouse Audit
```
1. DevTools → Lighthouse (o Shift+Ctrl+P)
2. Click "Generate report"
3. ESPERAR: 30-60 segundos

OBJETIVO:
[ ] Performance: >80
[ ] Accessibility: >90
[ ] Best Practices: >80
[ ] SEO: >90
```

---

## ✅ PASO 9: Testing de Animaciones

### 9.1 Fade In Cascada
```
TEST:
1. Recargar página (F5)
2. Observar cards aparecer:
   - Card 1: Aparece primero
   - Card 2: 0.05s después
   - Card 3: 0.1s después
   - ... cascada visual

VALIDA: Efecto waterfall, no todo de una vez
```

### 9.2 Hover Effects
```
TEST:
1. Pasar mouse sobre card
2. OBSERVAR:
   - Card sube 8px suavemente
   - Sombra se expande
   - Transición: 0.3s
   - Sin salto repentino

3. Sacar mouse
4. OBSERVAR:
   - Card baja suavemente
   - Sombra se contrae
```

### 9.3 Carrito Toggle
```
TEST:
1. Click toggle carrito
2. OBSERVAR:
   - Carrito se desliza suavemente
   - Tiempo: 0.3s
   - Sin saltos

3. Click nuevamente
4. OBSERVAR:
   - Se desliza de vuelta
   - Suave, sin lag
```

### 9.4 Desabilitar Animaciones (Testing)
Si el usuario tiene "Reduce Motion" activado:
```
Windows: Settings → Ease of Access → Display → Show animations
Mac: System Preferences → Accessibility → Display → Reduce motion

VERIFICAR: App aún funciona (animaciones muy rápidas o removidas)
```

---

## ✅ PASO 10: Testing de Errores

### 10.1 Error de Validación
```
TEST:
1. Click Finalizar sin nombre
2. VERIFICAR: Toast error rojo
3. Mensaje clara: "Nombre debe tener..."

4. Input: "ab" (2 caracteres)
5. Click Finalizar
6. VERIFICAR: Error mismo

7. Input: "Juan" (ok)
8. No input ciudad
9. Click Finalizar
10. VERIFICAR: Error ciudad obligatoria
```

### 10.2 Productos sin Imagen
```
TEST:
1. Esperar productos carguen
2. Si imagen falla (X rojo):
   - VERIFICAR: Fallback SVG aparece
   - Debe mostrar letra inicial coloreada
   - NO debe quedar blanco
```

### 10.3 Sin Conexión
```
TEST:
1. DevTools → Network tab
2. Dropdown "Throttling" → Offline
3. Recargar página
4. VERIFICAR: Toast "Sin conexión"
5. Carrito aún funciona (localStorage)
6. Intentar agregar → Toast: "Sin conexión"
7. Cambiar a "Online"
8. VERIFICAR: Toast "Conexión restaurada"
```

---

## ✅ PASO 11: Testing en Navegadores Diferentes

### 11.1 Chrome
```
✓ Debería funcionar perfectamente
```

### 11.2 Firefox
```
1. Abrir en Firefox
2. VERIFICAR: Mismo layout
3. VERIFICAR: Animaciones suaves
4. VERIFICAR: Colores iguales
```

### 11.3 Safari (si disponible)
```
1. Abrir en Safari
2. VERIFICAR: Funciones básicas
3. NOTA: -webkit prefixes aplicados ya
```

---

## ✅ PASO 12: Checklist Final

```markdown
DESKTOP:
[ ] Productos cargan
[ ] Grid: 5 columnas
[ ] Carrito visible sidebar
[ ] Agregar al carrito funciona
[ ] Toast aparece
[ ] Paginación funciona
[ ] Filtro funciona
[ ] Finalizar pedido funciona

TABLET:
[ ] Grid: 3 columnas
[ ] Carrito: Bottom sheet
[ ] Toggle carrito funciona
[ ] Items se pueden scroll
[ ] Finalizar pedido funciona

MÓVIL:
[ ] Grid: 2 columnas
[ ] FAB flotante visible
[ ] Toggle carrito (FAB) funciona
[ ] Bottom sheet aparece
[ ] Inputs accesibles
[ ] Botones big enough
[ ] Badge contador actualiza

ANIMACIONES:
[ ] Fade-in cascada en cards
[ ] Hover effect suave
[ ] Carrito toggle suave
[ ] Toast entrada/salida
[ ] Sin lag/stutter

VALIDACIONES:
[ ] Nombre validado
[ ] Ciudad validada
[ ] Toast error muestra
[ ] Toast éxito muestra

ACCESIBILIDAD:
[ ] Tab navega todo
[ ] Enter presiona botones
[ ] Focus visible
[ ] Dark mode funciona
[ ] Contraste ok

PERFORMANCE:
[ ] Console: sin errores
[ ] Network: <2s
[ ] Imágenes: 200 status
[ ] Lighthouse: >80
```

---

## 🔧 Si Algo No Funciona

### Problema: No carga nada
```
Solución:
1. Abrir Console (F12)
2. Ver si hay errores rojos
3. Copiar error y buscar en Google
4. Asegurar archivos están correctos
```

### Problema: Carrito no se ve
```
Solución:
1. Desplazarse a la derecha
2. O click FAB en móvil
3. Verificar no está collapsed (toggle)
```

### Problema: Imágenes no cargan
```
Solución:
1. Esperar 5 segundos (lazy load)
2. Verificar conexión internet
3. Verificar Cloudflare Worker activo
4. Ver Console por errores
```

### Problema: Animaciones lentas
```
Solución:
1. Cerrar otros tabs
2. DevTools → Performance → Record
3. Hacer acción lenta
4. Ver qué consume CPU
5. Si es GPU problem → reducir efectos
```

---

## ✅ Completado!

**Si todo pasa el testing → Listo para producción**

Tiempo total: ~20-30 minutos  
Resultado: Aplicación validada y lista para GitHub Pages

---

*Test completado: [fecha/hora]*  
*Tester: [Tu nombre]*  
*Status: ✅ Pasado / ⚠️ Issues / ❌ Fallido*
