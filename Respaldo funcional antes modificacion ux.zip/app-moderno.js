/* ═══════════════════════════════════════════════════════════════════════
   APP.JS - VERSIÓN MODERNA 2026
   Carrito Colapsable, Toasts, Mejor Gestión de Errores
   ═══════════════════════════════════════════════════════════════════════ */

// ═══════════════════════════════════════════════════════════════════════
// CONFIGURACIÓN
// ═══════════════════════════════════════════════════════════════════════

const API_URL = "https://script.google.com/macros/s/AKfycbzrRc0e5xD9tLPFPsQNgGdfGaHTkJ5uuCLW_ZGZad0I68MBQKtm11yQNkZNOjxFL8SuhQ/exec";
const API_KEY = "TIENDA_API_2026";
const CLOUDFLARE_PROXY = "https://tienda-image-proxy.pedidosnia-cali.workers.dev";
const LIMIT = 20;

// ═══════════════════════════════════════════════════════════════════════
// ESTADO GLOBAL
// ═══════════════════════════════════════════════════════════════════════

let page = 0;
let categoria = "";
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
let carritoAbierto = JSON.parse(localStorage.getItem("carritoState") ?? "true");

const productosDiv = document.getElementById("productos");
const categoriaFiltro = document.getElementById("categoriaFiltro");
const pageInfo = document.getElementById("pageInfo");
const carritoContainer = document.getElementById("carritoContainer");
const carritoToggle = document.getElementById("carritoToggle");
const carritoCloseBtn = document.getElementById("carritoCloseBtn");

// Cache Frontend
const cache = {
  productos: null,
  timestamp: 0,
  ttl: 10 * 60 * 1000 // 10 minutos
};

// ═══════════════════════════════════════════════════════════════════════
// NOTIFICACIONES (TOAST SYSTEM)
// ═══════════════════════════════════════════════════════════════════════

class ToastNotificacion {
  constructor() {
    this.container = document.getElementById("toastContainer");
  }

  mostrar(mensaje, tipo = "info", duracion = 3000) {
    const toast = document.createElement("div");
    toast.className = `toast toast-${tipo}`;
    
    // Emoji por tipo
    const emojis = {
      success: "✓",
      error: "✕",
      warning: "⚠",
      info: "ℹ"
    };
    
    toast.innerHTML = `
      <span>${emojis[tipo]}</span>
      <span>${mensaje}</span>
    `;
    
    this.container.appendChild(toast);
    
    // Auto remover
    setTimeout(() => {
      toast.style.animation = "slideOutRight 0.3s ease-out";
      setTimeout(() => toast.remove(), 300);
    }, duracion);
  }

  exito(mensaje) { this.mostrar(mensaje, "success"); }
  error(mensaje) { this.mostrar(mensaje, "error", 4000); }
  advertencia(mensaje) { this.mostrar(mensaje, "warning"); }
  info(mensaje) { this.mostrar(mensaje, "info"); }
}

const toast = new ToastNotificacion();

// ═══════════════════════════════════════════════════════════════════════
// GESTIÓN DEL CARRITO COLAPSABLE
// ═══════════════════════════════════════════════════════════════════════

function toggleCarrito() {
  carritoAbierto = !carritoAbierto;
  carritoContainer.classList.toggle("collapsed", !carritoAbierto);
  localStorage.setItem("carritoState", JSON.stringify(carritoAbierto));
}

// Event Listeners del Carrito
carritoToggle.addEventListener("click", toggleCarrito);
carritoCloseBtn.addEventListener("click", toggleCarrito);

// Aplicar estado inicial
if (!carritoAbierto) {
  carritoContainer.classList.add("collapsed");
}

// ═══════════════════════════════════════════════════════════════════════
// CARRITO - LÓGICA
// ═══════════════════════════════════════════════════════════════════════

function guardarCarrito() {
  localStorage.setItem("carrito", JSON.stringify(carrito));
  renderCarrito();
  actualizarBadgeCarrito();
}

function actualizarBadgeCarrito() {
  const cantidadTotal = carrito.reduce((acc, item) => acc + item.cantidad, 0);
  document.getElementById("cartoBadge").textContent = cantidadTotal;
}

function agregarAlCarrito(producto, cantidad) {
  cantidad = Number(cantidad);
  if (cantidad <= 0) {
    toast.advertencia("Cantidad debe ser mayor a 0");
    return;
  }

  const item = carrito.find(p => p.id === producto.id);

  if (item) {
    item.cantidad += cantidad;
    toast.info(`Cantidad actualizada: ${producto.nombre}`);
  } else {
    carrito.push({
      id: producto.id,
      nombre: producto.nombre,
      precio: producto.precio,
      cantidad: cantidad
    });
    toast.exito(`✓ ${producto.nombre} añadido`);
  }

  guardarCarrito();
}

function cambiarCantidad(id, delta) {
  const item = carrito.find(p => p.id === id);
  if (!item) return;

  item.cantidad += delta;

  if (item.cantidad <= 0) {
    const nombreProducto = item.nombre;
    carrito = carrito.filter(p => p.id !== id);
    toast.info(`${nombreProducto} removido del carrito`);
  } else {
    toast.info(`Cantidad actualizada`);
  }

  guardarCarrito();
}

function cambiarCantidadCard(id, delta) {
  const input = document.getElementById(`qty-${id}`);
  let val = Number(input.value) + delta;
  if (val < 1) val = 1;
  input.value = val;
}

function renderCarrito() {
  const cont = document.getElementById("carritoItems");
  const totalDiv = document.getElementById("carritoTotal");
  const vacioDiv = document.getElementById("carritoVacio");

  cont.innerHTML = "";
  let total = 0;

  if (carrito.length === 0) {
    vacioDiv.style.display = "flex";
    totalDiv.textContent = "$ 0";
    return;
  }

  vacioDiv.style.display = "none";

  carrito.forEach(p => {
    total += p.precio * p.cantidad;

    const itemDiv = document.createElement("div");
    itemDiv.className = "item";
    itemDiv.innerHTML = `
      <div class="item-info">
        <div class="item-name">${p.nombre}</div>
        <div class="item-price">$ ${Number(p.precio).toLocaleString()}</div>
      </div>
      <div class="qty">
        <button onclick="cambiarCantidad(${p.id}, -1)" title="Disminuir cantidad">−</button>
        <span>${p.cantidad}</span>
        <button onclick="cambiarCantidad(${p.id}, 1)" title="Aumentar cantidad">+</button>
      </div>
    `;
    cont.appendChild(itemDiv);
  });

  totalDiv.textContent = `$ ${total.toLocaleString()}`;
}

// ═══════════════════════════════════════════════════════════════════════
// VALIDACIÓN DE DATOS
// ═══════════════════════════════════════════════════════════════════════

function validarCliente(nombre, ciudad) {
  const errores = [];

  if (!nombre || nombre.trim().length < 3) {
    errores.push("Nombre debe tener mínimo 3 caracteres");
  }

  if (!ciudad || ciudad.trim().length < 2) {
    errores.push("Ciudad es obligatoria");
  }

  // Validar caracteres permitidos
  if (!/^[\w\s\-áéíóúàäëöüâêîôûãõñçñ.,']+$/i.test(nombre)) {
    errores.push("Nombre contiene caracteres inválidos");
  }

  if (!/^[\w\s\-áéíóúàäëöüâêîôûãõñ]+$/i.test(ciudad)) {
    errores.push("Ciudad contiene caracteres inválidos");
  }

  return errores;
}

// ═══════════════════════════════════════════════════════════════════════
// ENVÍO DE PEDIDOS
// ═══════════════════════════════════════════════════════════════════════

async function enviarPedido() {
  if (!carrito.length) {
    toast.error("El carrito está vacío");
    return;
  }

  const nombre = document.getElementById("clienteNombre").value;
  const ciudad = document.getElementById("clienteCiudad").value;

  // Validar datos
  const errores = validarCliente(nombre, ciudad);
  if (errores.length > 0) {
    toast.error(errores.join("\n"));
    return;
  }

  const total = carrito.reduce((acc, item) => acc + (item.precio * item.cantidad), 0);

  // Desactivar botón mientras se envía
  const btn = event.target;
  btn.disabled = true;
  btn.textContent = "Enviando...";

  try {
    const res = await fetch("https://pedido-proxy.pedidosnia-cali.workers.dev", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "crearPedido",
        key: API_KEY,
        cliente: { nombre: nombre.trim(), ciudad: ciudad.trim() },
        items: carrito,
        total
      })
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: Error en el servidor`);
    }

    const data = await res.json();

    if (data.success) {
      toast.exito(`✓ Pedido ${data.pedido_id} creado correctamente`);
      
      // Limpiar carrito
      carrito = [];
      guardascarrito();
      
      // Limpiar inputs
      document.getElementById("clienteNombre").value = "";
      document.getElementById("clienteCiudad").value = "";

      // Revertir botón
      btn.disabled = false;
      btn.textContent = "✓ Finalizar Pedido";
      
      // Cerrar carrito después de envío exitoso
      if (carritoAbierto) {
        setTimeout(() => toggleCarrito(), 1000);
      }
    } else {
      throw new Error(data.error || "Error al crear pedido");
    }
  } catch (error) {
    console.error("Error enviando pedido:", error);
    toast.error(`Error: ${error.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = "✓ Finalizar Pedido";
  }
}

// ═══════════════════════════════════════════════════════════════════════
// PRODUCTOS - FETCH Y CONVERSIÓN DE URLs
// ═══════════════════════════════════════════════════════════════════════

async function fetchProductos() {
  // Verificar cache
  if (cache.productos && Date.now() - cache.timestamp < cache.ttl) {
    console.log("📦 Usando cache de productos");
    return cache.productos;
  }

  try {
    console.log("📥 Obteniendo productos de API...");
    const res = await fetch(
      `${API_URL}?action=getProductos&offset=0&limit=3000&key=${API_KEY}`
    );

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: Error obteniendo productos`);
    }

    const data = await res.json();

    if (!data.items || !Array.isArray(data.items)) {
      throw new Error("Formato de respuesta inválido");
    }

    cache.productos = data.items;
    cache.timestamp = Date.now();

    console.log(`✓ ${data.items.length} productos cargados`);
    return data.items;
  } catch (error) {
    console.error("❌ Error fetch productos:", error);
    toast.error("Error cargando productos");
    return [];
  }
}

// Convertir URL de Google Drive a Proxy Cloudflare
function convertirDriveUrlAProxy(driveUrl) {
  if (!driveUrl) return null;

  if (driveUrl.startsWith(CLOUDFLARE_PROXY)) {
    return driveUrl;
  }

  // Extraer fileId de URLs de Google Drive
  const match = driveUrl.match(/[-\w]{25,}/);
  if (!match) return null;

  const fileId = match[0];
  return `${CLOUDFLARE_PROXY}/?fileId=${fileId}&key=${API_KEY}`;
}

// Generar SVG Fallback Colorido
function generarFallbackSVG(nombre, id) {
  const inicial = nombre ? nombre.charAt(0).toUpperCase() : '?';
  const colores = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A',
    '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2',
    '#F8B739', '#C71585', '#00CED1', '#FF4500'
  ];
  const color = colores[id % colores.length];

  return `data:image/svg+xml;base64,${btoa(`
    <svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
      <rect width="400" height="300" fill="${color}"/>
      <text x="200" y="160" font-size="120" fill="white" text-anchor="middle" font-family="Arial, sans-serif" font-weight="bold">${inicial}</text>
    </svg>
  `)}`;
}

// Cargar imagen con retry
function cargarImagenDirecta(img, src, fallback) {
  if (!src) {
    img.src = fallback;
    return;
  }

  img.src = src;

  img.onerror = () => {
    if (img.src !== fallback) {
      console.warn(`❌ Error cargando: ${src}, usando fallback`);
      img.src = fallback;
    }
  };
}

// ═══════════════════════════════════════════════════════════════════════
// RENDERIZADO DE PRODUCTOS
// ═══════════════════════════════════════════════════════════════════════

function render(productos) {
  productosDiv.innerHTML = "";

  if (productos.length === 0) {
    productosDiv.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: #757575;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">📭</div>
        <p>No hay productos en esta categoría</p>
      </div>
    `;
    return;
  }

  productos.forEach(p => {
    const proxyUrl = convertirDriveUrlAProxy(p.imagen);
    const fallbackSVG = generarFallbackSVG(p.nombre, p.id);

    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <img
        src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCI+PC9zdmc+"
        data-src="${proxyUrl || p.imagen}"
        data-fallback="${fallbackSVG}"
        loading="lazy"
        alt="${p.nombre}"
      >
      <div class="info">
        <h3>${p.nombre}</h3>
        <div class="precio">$ ${Number(p.precio).toLocaleString()}</div>

        <div class="qty-card">
          <button onclick="cambiarCantidadCard(${p.id}, -1)" title="Disminuir cantidad">−</button>
          <input
            type="number"
            min="1"
            value="1"
            id="qty-${p.id}"
            aria-label="Cantidad de ${p.nombre}"
          >
          <button onclick="cambiarCantidadCard(${p.id}, 1)" title="Aumentar cantidad">+</button>
        </div>

        <button class="btn"
          onclick='agregarAlCarrito(${JSON.stringify(p)}, document.getElementById("qty-${p.id}").value)'
          title="Agregar ${p.nombre} al carrito">
          🛒 Agregar
        </button>
      </div>
    `;

    productosDiv.appendChild(card);
  });

  activarLazyLoading();
}

// Lazy Loading con IntersectionObserver
function activarLazyLoading() {
  const imgs = document.querySelectorAll("img[data-src]");

  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const img = e.target;
        const src = img.dataset.src;
        const fallback = img.dataset.fallback;

        cargarImagenDirecta(img, src, fallback);

        img.removeAttribute("data-src");
        obs.unobserve(img);
      }
    });
  }, { rootMargin: "100px" });

  imgs.forEach(i => obs.observe(i));
}

// ═══════════════════════════════════════════════════════════════════════
// PAGINACIÓN Y FILTRADO
// ═══════════════════════════════════════════════════════════════════════

async function cargar() {
  try {
    const all = await fetchProductos();

    if (all.length === 0) {
      productosDiv.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
          <div style="font-size: 2rem; margin-bottom: 1rem;">❌</div>
          <p>No se pudieron cargar los productos</p>
        </div>
      `;
      pageInfo.textContent = "Error";
      return;
    }

    const filtrados = categoria
      ? all.filter(p => p.categoria === categoria)
      : all;

    const start = page * LIMIT;
    const items = filtrados.slice(start, start + LIMIT);

    const totalPages = Math.ceil(filtrados.length / LIMIT);
    pageInfo.textContent = `Página ${page + 1} de ${totalPages}`;

    render(items);

    document.getElementById("prev").disabled = page === 0;
    document.getElementById("next").disabled = start + LIMIT >= filtrados.length;
  } catch (error) {
    console.error("Error en cargar():", error);
    toast.error("Error cargando productos");
  }
}

// Event Listeners de Paginación
document.getElementById("prev").onclick = () => {
  if (page > 0) {
    page--;
    cargar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
};

document.getElementById("next").onclick = () => {
  page++;
  cargar();
  window.scrollTo({ top: 0, behavior: "smooth" });
};

categoriaFiltro.onchange = e => {
  categoria = e.target.value;
  page = 0;
  cargar();
};

// ═══════════════════════════════════════════════════════════════════════
// INICIALIZACIÓN
// ═══════════════════════════════════════════════════════════════════════

(async () => {
  try {
    console.log("🚀 Inicializando aplicación...");

    // Cargar y renderizar carrito inicial
    renderCarrito();
    actualizarBadgeCarrito();

    // Obtener productos
    const productos = await fetchProductos();

    if (productos.length === 0) {
      toast.error("No se pudieron cargar los productos");
      return;
    }

    // Llenar selector de categorías
    const categorias = [...new Set(productos.map(p => p.categoria))].sort();
    categorias.forEach(c => {
      const opt = document.createElement("option");
      opt.value = c;
      opt.textContent = c;
      categoriaFiltro.appendChild(opt);
    });

    // Cargar primera página
    cargar();

    console.log("✅ Aplicación lista");
  } catch (error) {
    console.error("❌ Error en inicialización:", error);
    toast.error("Error iniciando la aplicación");
  }
})();

// ═══════════════════════════════════════════════════════════════════════
// SERVICIOS PRÁCTICOS
// ═══════════════════════════════════════════════════════════════════════

// Auto guardar carrito cada 30 segundos (por si acaso)
setInterval(() => {
  localStorage.setItem("carrito", JSON.stringify(carrito));
}, 30000);

// Detectar conexión offline
window.addEventListener("online", () => {
  toast.exito("✓ Conexión restaurada");
});

window.addEventListener("offline", () => {
  toast.advertencia("⚠ Sin conexión a internet");
});

// ═══════════════════════════════════════════════════════════════════════
// DEBUG & DESARROLLO
// ═══════════════════════════════════════════════════════════════════════

// Comando global para limpiar carrito en consola
window.limpiarCarrito = () => {
  carrito = [];
  guardascarrito();
  toast.info("Carrito limpiado");
};

// Debugging
window.verCarrito = () => console.table(carrito);
window.verCache = () => console.log("Cache:", cache);
